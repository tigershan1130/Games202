Array3d v(1,2,4);
cout << v.sqrt() << endl;
